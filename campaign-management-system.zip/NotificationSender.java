public interface NotificationSender {
    void send(User user, Campaign campaign);
}