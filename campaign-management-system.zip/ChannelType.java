public enum ChannelType {
    SMS,
    EMAIL
}